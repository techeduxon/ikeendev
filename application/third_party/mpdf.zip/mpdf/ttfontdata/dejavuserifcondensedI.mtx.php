<?php
$name='DejaVuSerifCondensed-Italic';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 68,
  'FontBBox' => '[-755 -347 1480 1227]',
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='D:/xampp/htdocs/legalbrokers/application/third_party/mpdf/ttfonts/DejaVuSerifCondensed-Italic.ttf';
$TTCfontID='0';
$originalsize=302444;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensedI';
$panose=' 0 0 2 6 6 6 5 3 5 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>